# Deploy

Run ./deploy.sh
