Vendor A is cheaper.
